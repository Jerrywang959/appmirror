# HACKING guide for Deepin Image Viewer

## Project layout

### Coding layout

Deepin Image Viewer developed by Qt(QWidget).

### Others

## Core Design

## List of TODO (It’s the good way for contributing)

None.

## List of Workaround

None.

## Others
