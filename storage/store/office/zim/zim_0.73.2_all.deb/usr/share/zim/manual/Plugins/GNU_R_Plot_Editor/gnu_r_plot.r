x = seq(-4,4,by=0.01)
y = sin(x) + 1
plot(x,y,type='l')