#!/bin/bash
/data/opt/apps/top.yzzi.wallpaper/files/xwinwrap -ni -fs -s -st -sp -b -nf -- mplayer -wid WID -quiet -loop 0 ~/.config/OneWallpaper/video
